package chibibank.expensemint.expensetrackerapi;

public class Constants {
    public static final String API_SECRET_KEY = "Ch1b1B4nkK3y";
    public static final long TOKEN_VALIDITY = 2 * 60 * 60 * 1000;
}
